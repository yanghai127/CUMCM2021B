function shuchu_test = f(a,net,ps,ts)
shuru_test = mapminmax('apply', a, ps);
an = sim(net, shuru_test);          % Ԥ���������
shuchu_test = mapminmax('reverse', an, ts);
end
