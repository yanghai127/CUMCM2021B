%% 神经网络
clc,clear;
name = '神经网络训练集.xlsx';
a = xlsread(name,'sheet1','A2:I2971');
a = a';
in = a(1:6,:); out = a(9,:);
% 选出部分数据作为测试集
i = 1:40:2971;
in_test = in(:,i); out_test = out(i);
% in(:,i) = []; out(i) = [];
in_train = in; out_train = out;
% 归一化输入输出训练数据
[shuru, ps] = mapminmax(in_train);
[shuchu, ts] = mapminmax(out_train);
% 设置模型参数
a = 2; l = size(out_test, 2);
while a > 0.002
    net = newff(shuru,shuchu,6,{'tansig','tansig','tansig'},'trainlm');
    net.trainParam.goal = 0.00001;	% 训练目标最小误差，这里设置为0.00001
    net.trainParam.epochs = 1000;	% 训练次数，这里设置为10000次
    net.trainParam.lr = 0.02;       % 学习速率，这里设置为0.02
    % 训练
    net = train(net, shuru, shuchu);
    % 测试
    load net
    shuru_test = mapminmax('apply', in_test, ps);  % 归一化测试数据
    an = sim(net, shuru_test);          % 预测测试数据
    shuchu_test = mapminmax('reverse', an, ts);   % 恢复数据
    deltal = shuchu_test - out_test;    % 计算误差
    a = sum(abs(deltal)) / l;
end
% 绘图
figure; hold on; grid on;
plot(shuchu_test, 'b*-')
plot(out_test, 'ro-')
plot(deltal, 'square', 'MarkerFaceColor', 'b')
legend('乙醇预测收率', '乙醇期望收率', '误差')
xlabel('数据组数')
ylabel('乙醇收率')
b = sqrt(deltal * deltal' / l);
disp(['-----',num2str(l),'个测试样例误差如下-----'])
disp(['平均绝对误差为：', num2str(a)])
disp(['均方根误差为：', num2str(b)])

% 多次模拟，保存误差最小的模型

