%% 基于神经网络的遗传算法（温度<350）
clc,clear;
load net
load ps
load ts
popsize = 50; % 种群规模
elite = 0.2;  % 优势比例
lowerbound = [200 0 0 0 0];
upperbound = [500 6 300 300 3];
x = [345 2 200 200 1.68];
d = [10 0.2 10 10 0.1]; % 步长
% 初始化种群
pop = x;
while size(pop,1) < 50
    deltal = d.*(2*rand(1,5)-1);
    test = x + deltal;
    if test(1) < 350
        pop = [pop;test];
    end
end

% 开始迭代
maxiter = 4;
iter = 1;
while iter < maxiter
    alphi = [];
    for i = 1:50
        a = pop(i,:);
        a(6) = a(3)/a(4);
        alphi(i) = f(a',net,ps,ts);
    end
    [alphi_sort, index] = sort(alphi,'descend');
    pop = pop(index(1:popsize*elite),:);
    % 前五个每个生成8个子代
    for i = 1:5
        while size(pop,1) < popsize*elite+i*8
            deltal = d.*(2*rand(1,5)-1);
            test = pop(i,:) + deltal;
            if test(1) < 350
                pop = [pop;test];
            end
        end
    end
    iter = iter + 1;
end
a = pop(1,:);
a(6) = a(3)/a(4);
f(a',net,ps,ts)
a'


