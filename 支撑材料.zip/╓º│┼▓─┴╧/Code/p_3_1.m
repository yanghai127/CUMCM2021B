%% 基于神经网络的遗传算法
clc,clear;
load net
load ps
load ts
popsize = 50; % 种群规模
elite = 0.2;  % 优势比例
lowerbound = [200 0 0 0 0];
upperbound = [500 6 300 300 3];
x = [400 1 200 200 0.9];
d = [10 0.2 10 10 0.1]; % 步长
% 初始化种群
pop = x;
for i=1:49
    deltal = d.*(2*rand(1,5)-1);
    test = x + deltal;
    pop = [pop;test];
end

% 开始迭代
maxiter = 5;
iter = 1;
while iter < maxiter
    alphi = zeros(1,50);
    for i = 1:50
        a = pop(i,:);
        a(6) = a(3)/a(4);
        alphi(i) = f(a',net,ps,ts);
    end
    [alphi_sort, index] = sort(alphi,'descend');
    pop = pop(index(1:popsize*elite),:);
    % 前五个个体各生成8个子代
    for i = 1:5
        for j = 1:8
            deltal = d.*(2*rand(1,5)-1);
            test = pop(i,:) + deltal;
            pop = [pop;test];
        end
    end
    iter = iter + 1;
end
a = pop(1,:);
a(6) = a(3)/a(4);
res = f(a',net,ps,ts)
a'
