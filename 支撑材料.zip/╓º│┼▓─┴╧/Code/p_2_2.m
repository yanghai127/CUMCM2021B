%% 神经网络模型的灵敏度分析
clc,clear;
load ps
load ts
load net
name = '控制变量.xlsx';
sheet = {'温度','Co载重量','装料比','乙醇浓度'};
% 关于温度的灵敏度分析
figure(1)
subplot(2,2,1)
a = xlsread(name, sheet{1}, 'A1:T6');
shuru_test = mapminmax('apply', a, ps);
an = sim(net, shuru_test);          % 预测测试数据
shuchu_test = mapminmax('reverse', an, ts);
plot(a(1,:),shuchu_test)
hold on
grid on
xlabel(sheet{1})
ylabel('乙醇收率')
% 关于Co载重量的灵敏度分析
subplot(2,2,2)
a = xlsread(name, sheet{2}, 'A1:T6');
shuru_test = mapminmax('apply', a, ps);
an = sim(net, shuru_test);          % 预测测试数据
shuchu_test = mapminmax('reverse', an, ts);
plot(a(2,:),shuchu_test)
hold on
grid on
xlabel(sheet{2})
ylabel('乙醇收率')
% 关于装料比的灵敏度分析
subplot(2,2,3)
a = xlsread(name, sheet{3}, 'A1:T6');
shuru_test = mapminmax('apply', a, ps);
an = sim(net, shuru_test);          % 预测测试数据
shuchu_test = mapminmax('reverse', an, ts);
plot(a(6,:),shuchu_test)
hold on
grid on
xlabel(sheet{3})
ylabel('乙醇收率')

% 关于乙醇浓度的灵敏度分析
subplot(2,2,4)
a = xlsread(name, sheet{4}, 'A1:T6');
shuru_test = mapminmax('apply', a, ps);
an = sim(net, shuru_test);          % 预测测试数据
shuchu_test = mapminmax('reverse', an, ts);
plot(a(5,:),shuchu_test)
hold on
grid on
xlabel(sheet{4})
ylabel('乙醇收率')



