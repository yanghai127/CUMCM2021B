%% person相关系数的计算
clc,clear;
name = '插值数据及图表.xlsx';
sheet1 = '转化率插值数据';
sheet2 = 'C4烯烃选择性插值数据';
sheet = sheet1; % 更改这里可以计算另一个相关系数
% 温度与乙醇选择性person相关系数的计算
a12 = xlsread(name,sheet,'B2:C102');
a3 = xlsread(name,sheet,'D2:D202');
a = xlsread(name,sheet,'E2:V400');
a1 = a12(:,1);
a2 = a12(:,2);
tem12 = 250:350;
tem3 = 250:450;
tem = 250:400;
% qqplot(a1)
% 进行正态分布检验
n = 21; % 数据的列数
H = zeros(1,n);  % 初始化节省时间和消耗
P = zeros(1,n);
[H(1),P(1)] = jbtest(a1,0.05);
[H(2),P(2)] = jbtest(a2,0.05);
[H(3),P(3)] = jbtest(a3,0.05);
for i = 1:n-3
    [h,p] = jbtest(a(:,i),0.05);
    H(i+3)=h;
    P(i+3)=p;
end
disp(['在95%的置信区间上有',num2str(sum(H)),'种催化剂组合通过了JB检验'])
% disp(P)
% 计算person相关系数
R = zeros(1,n);
p = zeros(1,n);
[test1,test2] = corrcoef([a1,tem12']);
R(1) = test1(1,2);
p(1) = test2(1,2);
[test1,test2] = corrcoef([a2,tem12']);
R(2) = test1(1,2);
p(2) = test2(1,2);
[test1,test2] = corrcoef([a3,tem3']);
R(3) = test1(1,2);
p(3) = test2(1,2);
for i = 1:n-3
    [test1,test2] = corrcoef([a(:,i),tem']);
    R(i+3) = test1(1,2);
    p(i+3) = test2(1,2);
end
disp('相关系数如下：')
disp(R)
% disp('p值（双侧检验）：')
% disp(p)

