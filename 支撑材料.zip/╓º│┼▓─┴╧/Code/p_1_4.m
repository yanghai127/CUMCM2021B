%% 数据可视化（三维图）
clc,clear,close;
name = '插值数据及图表.xlsx';
sheet1 = '转化率插值数据2';
sheet2 = 'C4烯烃选择性插值数据2';
zlab1 = '乙醇转化率';
zlab2 = 'C4烯烃选择性';
% 更改下方sheet、zlab指向绘制不同三维图
sheet = sheet2;
zlab = zlab2;
% 不同催化剂组合下C4烯烃选择性与温度的三维图
a1 = xlsread(name,sheet,'B2:B22');
a2 = xlsread(name,sheet,'C2:C22');
a3 = xlsread(name,sheet,'D2:D42');
a = xlsread(name,sheet,'E2:V32');
n=21;
x1 = linspace(250,350,21);
x2 = x1;
x3 = linspace(250,450,41);
x = linspace(250,400,31);
figure(1)
surf([],[],[])
xlabel('温度')
ylabel('催化剂组合')
zlabel(zlab)
hold on;
plot3(x1,ones(1,21),a1);
plot3(x2,ones(1,21)*2,a2);
plot3(x3,ones(1,41)*3,a3);
for i=1:4
    plot3(x,ones(1,31)*(i+3),a(:,i));
end
yticks(1:7)
yticklabels({'A1','A2','A3','A4','A5','A6','A7'});
figure(2)
surf([],[],[])
xlabel('温度')
ylabel('催化剂组合')
zlabel(zlab)
hold on;
for i=1:7
    plot3(x,ones(1,31)*(i),a(:,i+4));
end
yticks(1:7)
yticklabels({'A8','A9','A10','A11','A12','A13','A14'});
figure(3)
surf([],[],[])
xlabel('温度')
ylabel('催化剂组合')
zlabel(zlab)
hold on;
for i=1:7
    plot3(x,ones(1,31)*(i),a(:,i+11));
end
yticks(1:7)
yticklabels({'B1','B2','B3','B4','B5','B6','B7'});



