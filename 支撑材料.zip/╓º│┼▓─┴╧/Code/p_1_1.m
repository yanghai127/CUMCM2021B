%% 三次样条插值
clc,clear;
name = '插值数据及图表.xlsx';
% 乙醇转化率插值
a=xlsread(name,'乙醇转化率','G2:Q7');
a(4,:)=[];
x=[250 275 300 350 400];
new_x = linspace(250,400,7);
new_y = zeros(7,size(a,2));
for i=1:size(a,2)
    test = spline(x,a(:,i),new_x);
    new_y(:,i) = test';
end
test_y = new_y(4,:);
xlswrite(name,test_y,'乙醇转化率','G5');
a = xlsread(name,'乙醇转化率','D2:V7');
b = xlsread(name,'乙醇转化率','B2:C6');
x1 = [250 275 300 325 350 400];
x2 = [250 275 300 325 350 400 450];
new_x2 = linspace(250,450,201);
new_x1 = linspace(250,400,151);
new_y = zeros(151,size(a,2)-1);
for i=1:size(a,2)
    if i==1
        test = a(:,i);
        test = [test;86.4];
        test_y = spline(x2,test,new_x2);
        xlswrite(name,test_y','转化率插值数据','D2');
    else
        new_y(1:151,i - 1) = spline(x1,a(:,i),new_x1);
    end
end
xlswrite(name,new_y,'转化率插值数据','E2');
xlswrite(name,new_x2','转化率插值数据','A2');
x = [250 275 300 325 350];
new_x = linspace(250,350,101);
new_y = zeros(101,2);
new_y(:,1) = spline(x,b(:,1),new_x);
new_y(:,2) = spline(x,b(:,2),new_x);
xlswrite(name,new_y,'转化率插值数据','B2');

% C4烯烃插值，与上部分代码基本相同
a=xlsread(name,'C4烯烃选择性','G2:Q7');
a(4,:)=[];
x=[250 275 300 350 400];
new_x = linspace(250,400,7);
new_y = zeros(7,size(a,2));
for i=1:size(a,2)
    test = spline(x,a(:,i),new_x);
    new_y(:,i) = test';
end
test_y = new_y(4,:);
xlswrite(name,test_y,'C4烯烃选择性','G5');
a = xlsread(name,'C4烯烃选择性','D2:V7');
b = xlsread(name,'C4烯烃选择性','B2:C6');
x1 = [250 275 300 325 350 400];
x2 = [250 275 300 325 350 400 450];
new_x2 = linspace(250,450,201);
new_x1 = linspace(250,400,151);
new_y = zeros(151,size(a,2)-1);
for i=1:size(a,2)
    if i==1
        test = a(:,i);
        test = [test;49.9];
        test_y = spline(x2,test,new_x2);
        xlswrite(name,test_y','C4烯烃选择性插值数据','D2');
    else
        new_y(1:151,i - 1) = spline(x1,a(:,i),new_x1);
    end
end
xlswrite(name,new_y,'C4烯烃选择性插值数据','E2');
xlswrite(name,new_x2','C4烯烃选择性插值数据','A2');
x = [250 275 300 325 350];
new_x = linspace(250,350,101);
new_y = zeros(101,2);
new_y(:,1) = spline(x,b(:,1),new_x);
new_y(:,2) = spline(x,b(:,2),new_x);
xlswrite(name,new_y,'C4烯烃选择性插值数据','B2');


